
FFmpeg.exe is required.

* Go to https://github.com/GyanD/codexffmpeg/releases
* Choose the "Essentials" build. e.g. "ffmpeg-6.0-essentials_build.zip" and download the archive.
* Unzip the archive and copy bin\ffmpeg.exe to : &nbsp;Binaries\DATA\FFMPEG
* The DATA folder must be within the folder containing the executable file.\
* For development, this may be "..\x64\Release".



